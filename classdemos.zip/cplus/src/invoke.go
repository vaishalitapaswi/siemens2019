package main

import (
	"fmt"
	"simplelib"
)

func main() {
	sl := simplelib.hello()
	fmt.Println(sl)
}
