package main

type emp struct {
	Empno  string
	Ename  string
	Salary int
}
