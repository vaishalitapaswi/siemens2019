package main

import (
	"fmt"
//    "github.com/aws/aws-lambda-go/lambda"
)


func show() (*string, error) {
    bk := "Hello World"
	return &bk,nil
    }


func main() {
   // lambda.Start(show)
   m,_:=show()
   fmt.Println(*m)
}