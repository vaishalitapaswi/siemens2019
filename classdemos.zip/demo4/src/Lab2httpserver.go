package main

import (
	"fmt"
	"io"
	"log"
	"net/http"
)

func two(w http.ResponseWriter, req *http.Request) {
	io.WriteString(w, "<h1>Two Page</h1>")
}

func main() {
	rootHandler := func(w http.ResponseWriter, req *http.Request) {
		io.WriteString(w, "<h1>Index Page</h1>")
	}

	http.HandleFunc("/", rootHandler)
	http.HandleFunc("/one", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "<H1>Hello One</H1>")
	})
	http.HandleFunc("/two", two)

	log.Fatal(http.ListenAndServe(":8080", nil))
}
