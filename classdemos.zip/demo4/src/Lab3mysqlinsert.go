package main

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
)

func main() {
	db, err := sql.Open("mysql",
		"admin:KFt0VNOS4g9wLSukN2D1@tcp(mydb.cphr8qotgspy.us-east-1.rds.amazonaws.com:3306)/innodb")

	if err != nil {
		fmt.Println("Error ", err)
		panic(err.Error)
	}
	fmt.Println(db)
	rows, err1 := db.Query("insert into emp values (11,'AAA',11000)")
	if err1 != nil {
		fmt.Println("Error inserting ", err1)
	} else {
		fmt.Println("Rows ", rows)
	}

}
