package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

type MyJsonObject struct {
	Data []struct {
		Avatar    string `json:"avatar"`
		Email     string `json:"email"`
		FirstName string `json:"first_name"`
		ID        int    `json:"id"`
		LastName  string `json:"last_name"`
	} `json:"data"`
	Page       int `json:"page"`
	PerPage    int `json:"per_page"`
	Total      int `json:"total"`
	TotalPages int `json:"total_pages"`
}

func main() {

	resp, err := http.Get("https://reqres.in/api/users?page=1")
	if err != nil {
		fmt.Println("Error ...", err)
	} else {
		defer resp.Body.Close()
		fmt.Println("Resp status ", resp.Status)
		if bcontent, err1 := ioutil.ReadAll(resp.Body); err1 == nil {
			var users MyJsonObject
			json.Unmarshal(bcontent, &users)
			fmt.Println(users.Page)
			fmt.Println("index\tId\tFirst_name\tLast_name\t")
			for index, content := range users.Data {
				fmt.Println(index, content.ID, content.FirstName, content.LastName)
			}
		}
	}
}
