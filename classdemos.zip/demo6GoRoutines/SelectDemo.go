package main

import (
	"fmt"
	"time"
)

func ShippingOne(c chan string) {

	for i := 0; i < 5; i++ {
		time.Sleep(10 * time.Millisecond)
	}
	c <- "Shipping Company One can take asgn"
}

func ShippingTwo(c chan string) {

	for i := 0; i < 5; i++ {
		time.Sleep(100 * time.Millisecond)
	}
	c <- "Shipping Company Two can take asgn"
}

func main() {
	s1 := make(chan string)
	s2 := make(chan string)
	go ShippingOne(s1)
	go ShippingTwo(s2)
	fmt.Println("Waiting for shipping confirmation")
	//	fmt.Println(<-s1)
	//	fmt.Println(<-s2)
	select {
	case str := <-s1:
		fmt.Println(str)
	case str := <-s2:
		fmt.Println(str)

	}
}
