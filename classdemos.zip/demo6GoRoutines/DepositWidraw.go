package main

import (
	"fmt"
	"sync"
)

var total int
var mutex = &sync.Mutex{}

func deposit(i int) {
	mutex.Lock()
	total++
	mutex.Unlock()
	fmt.Println("deposit ..", i, "   ", total)
}
func widraw(i int) {
	mutex.Lock()
	total--
	mutex.Unlock()
	fmt.Println("widraw ..", i, "   ", total)
}

func main() {

	for i := 0; i < 50; i++ {
		go deposit(i)
		go widraw(i)
	}
	for {
	}
}
