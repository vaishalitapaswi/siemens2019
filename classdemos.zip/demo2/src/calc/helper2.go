package calc


func Divide(i int, j int) int {
	return i / j
}
