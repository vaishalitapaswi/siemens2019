package main

import "fmt"

func cal(x, y int) (int, int) {
	add := x + y
	mult := x * y
	return add, mult
}

func cal1(x, y int) (add, mult int) {
	add = x + y + 10
	mult = x*y + 10
	return
}

func main() {
	fmt.Println(cal(30, 10))
	fmt.Println(cal1(30, 10))
}
