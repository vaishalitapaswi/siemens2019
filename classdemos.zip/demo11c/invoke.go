	package main

	import "fmt"
	import "rand"

	func main() {
		fmt.Println("Hello")
		fmt.Println("rand", rand.Random())
	}
