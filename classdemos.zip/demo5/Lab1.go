package main

import (
	"fmt"
	"time"
)

func m1() {
	for i := 0; i < 15000; i++ {
		fmt.Print("*")
		time.Sleep(100 * time.Millisecond)
	}
}
func m2() {
	for i := 0; i < 15000; i++ {
		fmt.Print("-")
		time.Sleep(100 * time.Millisecond)
	}
}
func main() {
	go m1()
	go m2()
	fmt.Println("Done !!!")
	for {
	}
}
