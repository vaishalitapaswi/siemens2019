package main

import "fmt"

func fib(max int) (arr [20]int) {
	arr[0] = 0
	arr[1] = 1
	for i := 2; arr[i-2] <= max; i++ {
		if arr[i-1]+arr[i-2] > max {
			break
		}
		arr[i] = arr[i-1] + arr[i-2]
	}
	return
}

func main() {
	fmt.Println("Enter a number to print fib..")
	no := 10
	fmt.Scanf("%d", &no)
	fmt.Println(fib(no))
}
