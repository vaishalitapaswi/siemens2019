package calc

func Add(i, j int) int {
	return i + j
}
