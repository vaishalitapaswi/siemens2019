package main

import (
	"calc"
	"fmt"
	"os"
	"strconv"
)

func main() {

	x, _ := strconv.Atoi(os.Args[1])
	y, _ := strconv.Atoi(os.Args[2])
	fmt.Println("sum = ", calc.Add(x, y))
	fmt.Println("division = ", calc.Divide(x, y))
}
