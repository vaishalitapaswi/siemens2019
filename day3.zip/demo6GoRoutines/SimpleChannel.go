package main

import "fmt"

func sum(s []int, c chan int) {
	sum := 0
	for _, v := range s {
		c <- v
		sum += v
	}
}

func main() {
	s := []int{7, 2, 8, -9, 4, 0}
	c := make(chan int)
	go sum(s[:len(s)/2], c)
	fmt.Println(c)
	x := <-c
	fmt.Println("Sum1 = ", x)
	x = <-c
	fmt.Println("Sum2 = ", x)
	x = <-c
	fmt.Println("Sum3 = ", x)
	x = <-c
	fmt.Println("Sum4 = ", x)

	//go sum(s[:3],c)
	//--> 7+2+8

	//go sum(s[len(s)/2:], c)
	//->go sum(3:6),c)
	//x, y := <-c, <-c // receive from c

	//fmt.Println(x, y, x+y)
}
