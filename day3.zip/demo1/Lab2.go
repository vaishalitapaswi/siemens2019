package main

import "fmt"

func main() {
	var c1, c2 = "Hello", "World "
	var a, b, c = 0, 1.23, false
	x := 0

	y := 1.23
	z := false
	x, name, age := 10, "aaa", 10
	x, name, age1 := 1000, "aaa", 10
	fmt.Println("c1 = ", c1, " c2= ", c2)
	fmt.Printf("c1 = %s c2 = %s\n", c1, c2)

	fmt.Println("a= ", a, " b= ", b, "c= ", c)
	fmt.Printf("a= %d, b= %f , c= %b\n", a, b, c)

	fmt.Printf("x= %d, y= %f , z = %s", x, y, z)

	fmt.Printf("%s is %d years old.\n", name, age)
	fmt.Printf("%s is %d years old.\n", name, age1)

}
