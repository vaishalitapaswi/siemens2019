package main

import (
	"fmt"
)

func main() {
	//var m map[string]int
	m := make(map[string]int)
	m["a"] = 100
	m["b"] = 200
	m["a"] = 300
	m["4"] = 300
	fmt.Println(m["a"])
	fmt.Println("len = ", len(m))
	fmt.Println(m)

}
