package main

import (
	"fmt"
	"strconv"
)

func main() {
	//var strarr [5]string
	strarr := [5]string{}
	for i := 0; i < 2; i++ {
		strarr[i] = "a" + strconv.Itoa(i)
	}
	fmt.Println(strarr)
	slice1 := strarr[:]
	slice1[0] = "aaaa"
	fmt.Println(slice1)
	fmt.Println(strarr)
	printdetails(slice1)

	slice1 = append(slice1, "new")
	printdetails(slice1)
	slice1 = append(slice1, "new1")
	slice1 = append(slice1, "new2")
	slice1 = append(slice1, "new3")
	slice1 = append(slice1, "new3")
	slice1 = append(slice1, "new3")
	printdetails(slice1)
}
func printdetails(a []string) {
	fmt.Println("Len = ", len(a))
	fmt.Println("Cap = ", cap(a))
	fmt.Println("address =", &a)
}
