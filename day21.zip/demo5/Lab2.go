package main

import (
	"fmt"
	"sync"
	"time"
)

var count int = 0

func m1() {
	for i := 1; i <= 100; i++ {
		locvar := count
		time.Sleep(10 * time.Millisecond)
		locvar += 1
		count = locvar
	}
	fmt.Println("Current Count = ", count)
}
func main() {
	var wg sync.WaitGroup
	wg.Add(1)

	go func() {
		m1()
		wg.Done()
	}()

	fmt.Println("Current Count = ", count)
	wg.Add(1)
	go func() {
		m1()
		wg.Done()
	}()

	fmt.Println("Current Count = ", count)
	wg.Add(1)
	go func() {
		m1()
		wg.Done()
	}()
	fmt.Println("Current Count = ", count)
	wg.Wait()
}
