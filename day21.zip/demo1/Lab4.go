package main

import (
	"fmt"
	"os"
	"strconv"
)

func add(i, j int64) int64 {
	return i + j
}
func divide(i int64, j int64) int64 {
	return i / j
}

func main() {
	x, _ := strconv.ParseInt(os.Args[1], 10, 8)
	y, _ := strconv.ParseInt(os.Args[2], 10, 16)
	fmt.Println("sum = ", add(x, y))
	fmt.Println("division = ", divide(x, y))
}
