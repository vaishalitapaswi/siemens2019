package main

import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/go-sql-driver/mysql"
	_ "github.com/magiconair/properties"
)

func connect() *sql.DB {
	log.Println("Connecting ")
	url, _ := p.Get("url")
	username, _ := p.Get("username")
	password, _ := p.Get("password")
	dbname, _ := p.Get("dbname")
	dbconurl := username + ":" + password + "@tcp(" + url + ":3306)/" + dbname
	fmt.Println(dbconurl)
	db, err := sql.Open("mysql", dbconurl)
	if err != nil {
		fmt.Println("Error ", err)
		panic(err.Error)
	}
	return db

}

func Insert(e emp) {
	fmt.Println("in insert")
	db := connect()
	rows, err1 := db.Query("insert into emp values (?,?,?)", e.Empno, e.Ename, e.Salary)
	if err1 != nil {
		log.Fatalln("Error inserting ", err1)
	} else {
		fmt.Println("Rows ", rows)
	}
	log.Println("Inserted")
}
