package main

import (
	"fmt"
	"os"
)

func main() {
	sum := 0
	length := len(os.Args)
	for i := 1; i < length; i++ {
		fmt.Println(i, os.Args[i])
		sum += len(os.Args[i])
	}
	fmt.Println("final = ", sum)

}
