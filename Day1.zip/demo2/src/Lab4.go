package main

import "fmt"

type Vertex struct {
	X, Y float64
}

func (v *Vertex) Scale() {
	v.X = v.X * 2
	v.Y = v.Y * 4
}
func main() {
	v1 := &Vertex{3, 4}
	v1.Scale()
	fmt.Println(v1)
	fmt.Println(v1)
	v2 := v1.Abs()
	fmt.Println(v2)
}
func (v Vertex) Abs() Vertex {
	v.X = 100
	v.Y = 200
	return v
}
